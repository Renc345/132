﻿using AccountingOfArrivalApp.Classes;
using AccountingOfArrivalApp.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using DataVis = System.Windows.Forms.DataVisualization;

namespace AccountingOfArrivalApp.Pages.Statistics_Details
{
    /// <summary>
    /// Логика взаимодействия для PageStatistics.xaml
    /// </summary>
    public partial class PageStatistics : Page
    {
        public PageStatistics()
        {
            InitializeComponent();

            cmbYear.ItemsSource = GetYears();
            cmbYear.SelectedIndex = 0;

            CreatingСhart(0, int.Parse(cmbYear.SelectedItem.ToString()));
            chartArrivals.ChartAreas[0].AxisY.Title = "Поступления";

            chartArrivals.Series[0].Font = new Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisX.TitleFont = new Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisY.TitleFont = new Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Segoe UI", 12);
            chartArrivals.ChartAreas[0].AxisY.LabelStyle.Font = new Font("Segoe UI", 12);
            chartArrivals.Series[0].BorderWidth = 5;
        }

        public void CreatingChartTitle()
        {
            string title = "Диаграмма поступлений";
            if (rbQuarter.IsChecked == true) title += " по кварталам за " + cmbYear.SelectedItem.ToString() + " год";
            else if (rbMonth.IsChecked == true) title += " по месяцам за " + cmbYear.SelectedItem.ToString() + " год";
            else title += " по годам";
            txbChartTitle.Text = title;
            ShowTitle_Click(null, null);
        }

        public List<int> GetYears()
        {
            List<int> Years = new List<int>();
            foreach (InvoicesOnArrival invoice in InvoicesOnArrival.ToList()) Years.Add(((DateTime)invoice.DeliveryDate).Year);
            return Years.Distinct().OrderBy(x => x).ToList();
        }

        public void CreatingСhart(int mode, int year)
        {
            chartArrivals.Series[0].Points.Clear();
            if (mode == 0)
            {
                List<InvoicesOnArrival> list = InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == year).ToList();
                int Quarter1 = 0;
                int Quarter2 = 0;
                int Quarter3 = 0;
                int Quarter4 = 0;
                foreach (InvoicesOnArrival invoice in list)
                {
                    if (invoice.DeliveryDate >= new DateTime(year,1,1,0,0,0) && invoice.DeliveryDate < new DateTime(year, 3, 31, 0, 0, 0)) Quarter1++;
                    else if (invoice.DeliveryDate >= new DateTime(year,4,1,0,0,0) && invoice.DeliveryDate < new DateTime(year, 6, 30, 0, 0, 0)) Quarter2++;
                    else if (invoice.DeliveryDate >= new DateTime(year,7,1,0,0,0) && invoice.DeliveryDate < new DateTime(year, 3, 30, 0, 0, 0)) Quarter3++;
                    else Quarter4++;
                }
                chartArrivals.Series[0].Points.Add(Quarter1).AxisLabel = "I";
                chartArrivals.Series[0].Points.Add(Quarter2).AxisLabel = "II";
                chartArrivals.Series[0].Points.Add(Quarter3).AxisLabel = "III";
                chartArrivals.Series[0].Points.Add(Quarter4).AxisLabel = "IV";
                chartArrivals.ChartAreas[0].AxisX.Title = "Кварталы";
            }
            else if (mode == 1)
            {
                List<InvoicesOnArrival> list = InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == year).ToList();
                int[] Months = new int[] { 0,0,0,0,0,0,0,0,0,0,0,0 };
                foreach (InvoicesOnArrival invoice in list)
                {
                    int Month = ((DateTime)invoice.DeliveryDate).Month;
                    Months[Month - 1]++;
                }
                for (int i = 0; i < Months.Length; i++) chartArrivals.Series[0].Points.Add(Months[i]).AxisLabel = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(i + 1);
                chartArrivals.ChartAreas[0].AxisX.Title = "Месяцы";
            }
            else
            {
                foreach (int y in GetYears()) chartArrivals.Series[0].Points.Add(InvoicesOnArrival.ToList().Where(x => ((DateTime)x.DeliveryDate).Year == y).ToList().Count()).AxisLabel = y.ToString();
                chartArrivals.ChartAreas[0].AxisX.Title = "Года";
            }
            CreatingChartTitle();
        }

        private void CmbYear_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int year = int.Parse(cmbYear.SelectedItem.ToString());
            if (rbQuarter.IsChecked == true) CreatingСhart(0, year);
            else if (rbMonth.IsChecked == true) CreatingСhart(1, year);
            else CreatingСhart(2, year);
        }

        private void ReportType_Click(object sender, RoutedEventArgs e)
        {
            int year = int.Parse(cmbYear.SelectedItem.ToString());
            switch (((RadioButton)sender).Name)
            {
                case "rbQuarter":
                    cmbYear.IsEnabled = true;
                    CreatingСhart(0, year);
                    break;
                case "rbMonth":
                    cmbYear.IsEnabled = true;
                    CreatingСhart(1, year);
                    break;
                case "rbYear":
                    cmbYear.IsEnabled = false;
                    CreatingСhart(2, year);
                    break;
                default:
                    break;
            }
        }

        private void ReportType_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            RadioButton rb = new RadioButton();
            switch (((TextBlock)sender).Text)
            {
                case "По кварталам":
                    rb = rbQuarter;
                    break;
                case "По месяцам":
                    rb = rbMonth;
                    break;
                case "По годам":
                    rb = rbYear;
                    break;
                default:
                    break;
            }
            rb.IsChecked = true;
            ReportType_Click(rb, null);
        }

        private void ChartType_Click(object sender, RoutedEventArgs e)
        {
            switch (((RadioButton)sender).Name)
            {
                case "rbColumn":
                    chartArrivals.Series[0].ChartType = DataVis.Charting.SeriesChartType.Column;
                    break;
                case "rbBar":
                    chartArrivals.Series[0].ChartType = DataVis.Charting.SeriesChartType.Bar;
                    break;
                case "rbPie":
                    chartArrivals.Series[0].ChartType = DataVis.Charting.SeriesChartType.Pie;
                    break;
                case "rbLine":
                    chartArrivals.Series[0].ChartType = DataVis.Charting.SeriesChartType.Line;
                    break;
                default:
                    break;
            }
        }

        private void ChartType_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            RadioButton rb = new RadioButton();
            switch (((TextBlock)sender).Text)
            {
                case "Гистограмма":
                    rb = rbColumn;
                    break;
                case "Линейчатая":
                    rb = rbBar;
                    break;
                case "Круговая":
                    rb = rbPie;
                    break;
                case "График":
                    rb = rbLine;
                    break;
                default:
                    break;
            }
            rb.IsChecked = true;
            ChartType_Click(rb, null);
        }

        private void TxbChartTitle_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txbChartTitle.Text == "") chartArrivals.Titles.Clear();
            else
            {
                if (chartArrivals.Titles.Count == 0)
                {
                    chartArrivals.Titles.Add(txbChartTitle.Text);
                    chartArrivals.Titles[0].Font = new Font("Segoe UI", 15, System.Drawing.FontStyle.Bold);
                }
                else chartArrivals.Titles[0].Text = txbChartTitle.Text;
            }
        }

        private void ShowTitle_Click(object sender, RoutedEventArgs e)
        {
            if (cbShowTitle.IsChecked == true) chartArrivals.Titles.Clear();
            else
            {
                if (chartArrivals.Titles.Count == 0)
                {
                    chartArrivals.Titles.Add(txbChartTitle.Text);
                    chartArrivals.Titles[0].Font = new Font("Segoe UI", 15, System.Drawing.FontStyle.Bold);
                }
                else chartArrivals.Titles[0].Text = txbChartTitle.Text;
            }
        }

        private void ShowTitle_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            cbShowTitle.IsChecked = !cbShowTitle.IsChecked;
            ShowTitle_Click(null, null);
        }

        private void ShowValues_Click(object sender, RoutedEventArgs e)
        {
            chartArrivals.Series[0].IsValueShownAsLabel = (bool)cbShowValues.IsChecked;
        }

        private void ShowValues_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            cbShowValues.IsChecked = !cbShowValues.IsChecked;
            chartArrivals.Series[0].IsValueShownAsLabel = (bool)cbShowValues.IsChecked;
        }

        private void BackColor_Click(object sender, RoutedEventArgs e)
        {
            chartArrivals.Series[0].LabelBackColor = cbBackColor.IsChecked == true ? Color.White : Color.Transparent;
        }

        private void BackColor_PreviewMouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            cbBackColor.IsChecked = !cbBackColor.IsChecked;
            chartArrivals.Series[0].LabelBackColor = cbBackColor.IsChecked == true ? Color.White : Color.Transparent;
        }

        private void ColourDropDown_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            switch (ColourDropDown.SelectedIndex)
            {
                case 0:
                    chartArrivals.Palette = DataVis.Charting.ChartColorPalette.BrightPastel;
                    break;
                case 1:
                    chartArrivals.Palette = DataVis.Charting.ChartColorPalette.Berry;
                    break;
                case 2:
                    chartArrivals.Palette = DataVis.Charting.ChartColorPalette.Pastel;
                    break;
                case 3:
                    chartArrivals.Palette = DataVis.Charting.ChartColorPalette.Grayscale;
                    break;
                case 4:
                    chartArrivals.Palette = DataVis.Charting.ChartColorPalette.SemiTransparent;
                    break;
                default:
                    break;
            }
        }

        private void BtnExportChart_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SaveFileDialog sfd = new SaveFileDialog { Filter = "PNG (*.png)|*.png|JPG (*.jpg)|*.jpg|JPEG (*.jpeg)|*.jpeg", Title = "Выберите фото/изображение пользователя", FileName = txbChartTitle.Text };
                if (sfd.ShowDialog() == true)
                {
                    var ChartBmp = new Bitmap(chartArrivals.Size.Width, chartArrivals.Size.Height);
                    var ChartBounds = new Rectangle(0, 0, chartArrivals.Size.Width, chartArrivals.Size.Height);
                    chartArrivals.DrawToBitmap(ChartBmp, ChartBounds);
                    ChartBmp.Save(sfd.FileName);
                    MessageBox.Show("Изображение диаграммы успешно сохранено!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error); }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassHelper.frmObj.Navigate(new PageArrivals());
        }
    }
}
